from PIL import Image 
import numpy as np

def getmatrix (imagepath,height,filename):
    imagebw = Image.open(imagepath).convert('L')
    macierz1=[]
    pixels = imagebw.getdata()
    for i in pixels:
        if i == 0:
            macierz1.append(0)
        elif i == 255:
            macierz1.append(1)
    splited = np.array_split(macierz1,height)
    np.savetxt(filename, splited, fmt = '%d')
     
getmatrix ("inicjały2.png", 60, "inicjały5.txt")
