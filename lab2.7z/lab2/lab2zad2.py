from PIL import Image   # Python Imaging Library
import numpy as np

nowa_inicjal = np.loadtxt("zadanie6macierz.txt", dtype = np.bool_ ) # wczytanie tablicy z pliku dane1.txt
dane_obrazka = np.asarray(obrazek)
print("typ danych tablicy", dane_obrazka.dtype)  # typ danych przechowywanych w tablicy
print("rozmiar tablicy", dane_obrazka.shape)  # rozmiar tablicy - warto porównac z wymiarami obrazka
print("liczba elementow", dane_obrazka.size)  # liczba elementów tablicy
print("wymiar tablicy", dane_obrazka.ndim) # wymiar mówi czy to jest talica 1D, 2d, 3D ...
print("wymiar wyrazu tablicy", dane_obrazka.itemsize)  # pokazuje ile współrzednych trzeba do opisania wyrazu tablicy (piksela)
print("pierwszy wyraz", dane_obrazka[0][0])
print("drugi wyraz", dane_obrazka[1][0])
print("***************************************")
print(dane_obrazka)   # mozna odkomentować, zeby zobaczyć tablicę
print(nowa_inicjal)
print("--------------")
print(dane_obrazka)
porownanie = nowa_inicjal == dane_obrazka # zwraca TRUE jesli tablice są identyczne (przy czym True = 1, False = 0), w przeciwnym przypadku False
czy_rowne = porownanie.all()
print(czy_rowne)