import numpy as np

def pseudokod_zad4a(x,y):
    macierz=[]
    góra=[]
    boki=[]
    for i in range(x):
        góra.append(0)
    
    for g in range(x):
        if g < 20 or g >=180:
            boki.append(0)
        elif 20 <= g < 180 :
            boki.append(1) 
    
    for j in range(y):
        if j < 20 or j >= 180:
            macierz.append(góra)
        elif 20 <= j < 180 :
            macierz.append(boki)
    np.savetxt('rozwiazanie_zad4a.txt', macierz, fmt = '%d')


def pseudokod_zad4b(x,y):
    macierz=[]
    bloczek=[]
    for i in range(x):
        if i < 20 or 40<=i<60 or 80<=i<100 or  120<=i<140 or 160<=i<180 :
            bloczek.append(0)
        else:
            bloczek.append(1)    

    for j in range(y):
        macierz.append(bloczek)
    np.savetxt('rozwiazanie_zad4b.txt', macierz, fmt = '%d')

def pseudokod_zad4c(x,y):
    c = np.ones((x, y))
    for i in range (0,len(c)):
            for j in range(0, len(c)):
                if i == j:
                    c[i-1][0:j] = 0
    np.savetxt('rozwiazanie_zad4c.txt', c, fmt = '%d')

pseudokod_zad4a(200,200)
print("##############################")
pseudokod_zad4b(200,200)
print("##############################")
pseudokod_zad4c(200,200)