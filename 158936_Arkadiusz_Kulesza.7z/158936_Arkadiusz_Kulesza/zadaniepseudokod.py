from PIL import Image 
import numpy as np
from numpy.core.defchararray import split
image1 =  Image.open ("zad2_a.png").convert('L')
image2 =  Image.open ("zad2_b.png").convert('L')
image3 =  Image.open ("zad2_c.png").convert('L')
image3 =  Image.open ("inicjały.png").convert('L')
def getmatrix (imagepath):
    imagebw = Image.open(imagepath).convert('L')
    macierz2=[]
    macierz1=[]
    pixels = imagebw.getdata()
    for i in pixels:
        if i == 0:
            macierz1.append(0)
        elif i == 255:
            macierz1.append(1)
    splited = np.array_split(macierz1,15)
    for x in splited:
        macierz2.append(x)
        # print("\n")
        
     
getmatrix("zad2_a.png")
print("\n")
getmatrix("zad2_b.png")
print("\n")
getmatrix("zad2_c.png")
np.savetxt('rozwiazanie_zad5.txt',getmatrix("inicjały.png"), fmt = '%d')