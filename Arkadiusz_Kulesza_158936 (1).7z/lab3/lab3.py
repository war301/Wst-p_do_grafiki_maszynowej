from PIL import Image   # Python Imaging Library
import numpy as np
from numpy.lib.type_check import imag

def obraz1(w,h,dzielnik):
    nazwa="obraz1 "+str(w)+"x"+str(h)+"x"+str(dzielnik)+".bmp"
    t = (h, w)  # rozmiar tablicy
    tab = np.zeros(t, dtype=np.uint8)  # deklaracja tablicy wypełnionej zerami - czarna
    g = int(min(w, h) / dzielnik)  # wyznaczenie gości  ramki
    ilosc_ramek = h // g

    for i in range(ilosc_ramek+1):
        print(i)
        z1 = h - (g * i)
        z2 = w - (g * i)
        if i % 2 == 0:
            tab[g*i:z1 ,g*i:z2] = 0  # skrócona wersja ustawienia wartości dla prostokatnego fragmentu tablicy [zakresy wysokości, zakresy szerokości] tablicy
        else:
            tab[g*i:z1 , g*i:z2] = 1
    tab=tab * 255
    im_ramka = Image.fromarray(tab)
    im_ramka.show()
    #obraz.save(nazwa)

obraz1(200, 100, 8)

def obraz2(w,h,dzielnik):
    nazwa="obraz2 "+str(w)+"x"+str(h)+"x"+str(dzielnik)+".bmp"
    t = (h, w)
    k=0
    tab = np.ones(t, dtype=np.uint8)
    g = int(w / dzielnik)
    for y in range(w):
        for x in range(h):
            if y in range(2*k*(g), ((2*k+1)*(g))):
                tab[x][y]=0
        if y==((2*k+1)*(g)):
            k+=1 
    tab = tab * 255
    obraz = Image.fromarray(tab)  # tworzy obraz
    obraz.show()
    #obraz.save(nazwa)

obraz2(800,400,40)

def obraz3(m,n):
    nazwa="obraz3 m="+str(m)+" n="+str(n)+".bmp"
    w=120
    h=60
    t = (h, w)
    tab = np.ones(t, dtype=np.uint8)
    for y in range(w):
        for x in range(h):
            for y in range(w):
                if (x < n and y < m) or (x >= n and y >= m):
                    tab[x][y]=0
    tab = tab * 255
    obraz = Image.fromarray(tab)
    obraz.show()
    #obraz.save(nazwa)

obraz3(50,20)
obraz3(10,40)

#obraz kwadratowy z rąbem w środku 
def obraz4(n):
    nazwa="obraz4 m="+str(n)+" n="+str(n)+".bmp"
    srodek = np.diag([0 for x in range(n)])
    for x in range(int(n/2), n, 1):
        gorny_rog = np.diag([1 for n in range(n - x)], x)
        srodek = srodek + gorny_rog
    for x in range(int(n/2), n, 1):
        gorny_rog = np.diag([1 for n in range(n - x)], -x)
        srodek = srodek + gorny_rog
    print(srodek)
    srodek1 = np.flip(srodek, 1)
    print(srodek1)
    matrix = srodek + srodek1


    matrix = (matrix * 255).astype(np.uint8)
    obraz = Image.fromarray(matrix)  # tworzy obraz
    obraz.show()
    #obraz.save(nazwa)

obraz4(200)

def zad2(plik):
    obraz = Image.open(plik)
    
    matrix=np.array(obraz)
    for x in range(len(matrix)):
        for y in range(len(matrix[0])):
            if matrix[x][y]==0:
                matrix[x][y]=1
            else:
                matrix[x][y]=0
    matrix = matrix * 255
    negatywobrazu= Image.fromarray(matrix)
    negatywobrazu.show()
    nazwa="Negatyw_"+plik+".jpg"
    #negatyw.save(nazwa)

zad2("inicjały.bmp")

def zad321(plik1, plik2):
    obraz1=Image.open(plik1)
    obraz2=Image.open(plik2)
    matrix1=np.array(obraz1)
    matrix2=np.array(obraz2)
    for x in range(len(matrix1)):
        for y in range(len(matrix1[0])):
            if matrix1[x][y] == 0 and matrix2[x][y] == 0:
                matrix1[x][y]=0
            else:     
               matrix1[x][y]=1
    matrix1 = matrix1 * 255
    wspolna = Image.fromarray(matrix1)
    wspolna.show()
    #wspolna.save("czesc_wspolna_czarne.bmp")
    

zad321("piorun.bmp","trójkąt.bmp")


def zad322(plik1, plik2):
    obraz1=Image.open(plik1)
    obraz2=Image.open(plik2)
    matrix1=np.array(obraz1)
    matrix2=np.array(obraz2)
    for x in range(len(matrix1)):
        for y in range(len(matrix1[0])):
            if matrix1[x][y] == 0 or matrix2[x][y] == 0:
                matrix1[x][y]=0
            else:     
               matrix1[x][y]=1
    matrix1 = matrix1 * 255
    suma = Image.fromarray(matrix1)
    suma.show()
    #suma.save("suma_czarnych.bmp")


zad322("piorun.bmp","trójkąt.bmp")

def zad323 (plik1, plik2):
    obraz1=Image.open(plik1)
    obraz2=Image.open(plik2)
    matrix1=np.array(obraz1)
    matrix2=np.array(obraz2)
    for x in range(len(matrix1)):
        for y in range(len(matrix1[0])):
            if matrix1[x][y] == 0 and matrix2[x][y] == 0:
                matrix1[x][y]=1
            
    matrix1 = matrix1 * 255
    roznica = Image.fromarray(matrix1)
    roznica.show()
    #roznica.save("roznica_czarnych.bmp")

zad323("piorun.bmp","trójkąt.bmp")

def zad324 (plik1, plik2):
    obraz1=Image.open(plik1)
    obraz2=Image.open(plik2)
    matrix1=np.array(obraz1)
    matrix2=np.array(obraz2)
    for x in range(len(matrix1)):
        for y in range(len(matrix1[0])):
            if matrix1[x][y] == 1 and matrix2[x][y] == 1:
                matrix1[x][y]=1
            else:     
               matrix1[x][y]=0
    matrix1 = matrix1 * 255
    wspolna = Image.fromarray(matrix1)
    wspolna.show()
    #wspolna.save("czesc_wspolna_bialych.bmp")

zad324("piorun.bmp","trójkąt.bmp")

def zad325 (plik1, plik2):
    obraz1=Image.open(plik1)
    obraz2=Image.open(plik2)
    matrix1=np.array(obraz1)
    matrix2=np.array(obraz2)
    for x in range(len(matrix1)):
        for y in range(len(matrix1[0])):
            if matrix1[x][y] == 1 or matrix2[x][y] == 1:
                matrix1[x][y]=1
            else:     
               matrix1[x][y]=0
    matrix1 = matrix1 * 255
    suma = Image.fromarray(matrix1)
    suma.show()
    #suma.save("suma_bialych.bmp")

zad325("piorun.bmp","trójkąt.bmp")

def zad326 (plik1, plik2):
    obraz1=Image.open(plik1)
    obraz2=Image.open(plik2)
    matrix1=np.array(obraz1)
    matrix2=np.array(obraz2)
    for x in range(len(matrix1)):
        for y in range(len(matrix1[0])):
            if matrix1[x][y] == 1 and matrix2[x][y] == 1:
                matrix1[x][y]=0
    
    matrix1 = matrix1 * 255
    roznica = Image.fromarray(matrix1)
    roznica.show()
    #roznica.save("roznica_bialych.bmp")

zad326("piorun.bmp","trójkąt.bmp")

